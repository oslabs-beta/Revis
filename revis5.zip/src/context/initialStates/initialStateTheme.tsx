const theme: { light: boolean } = {
  light: false,
};

export default theme;
