import { CurrentServer } from '../interfaces';

const selectedServer: CurrentServer = {
  name: '',
  endpoint: '',
  password: '',
  port: '',
  sessionToken: '',
};
export default selectedServer;
