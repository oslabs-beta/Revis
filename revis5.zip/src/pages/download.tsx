import React from "react";
import Download from "../components/StaticPages/Download";
function download() {
  return <div>
    <Download />
  </div>;
}

export default download;
