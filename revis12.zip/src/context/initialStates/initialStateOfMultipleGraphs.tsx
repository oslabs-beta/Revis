const metricsBeingCompared: {} = {};

export default metricsBeingCompared;
