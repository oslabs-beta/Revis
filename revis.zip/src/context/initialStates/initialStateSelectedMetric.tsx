const selectedMetric: string = '';

export default selectedMetric;
