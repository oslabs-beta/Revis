const user: { username: string } = {
  username: '',
};

export default user;
