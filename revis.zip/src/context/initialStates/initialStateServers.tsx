import { Server } from '../interfaces';

const Servers: Server[] = [];

export default Servers;
