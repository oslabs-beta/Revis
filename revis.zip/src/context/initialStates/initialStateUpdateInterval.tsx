import { Interval } from '../interfaces';

const interval: Interval = {
  update: true,
  interval: 10000,
};

export default interval;
