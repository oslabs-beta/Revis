import { MetricHistoryInterface } from '../interfaces';

const MetricHistory: MetricHistoryInterface[] = [];

export default MetricHistory;
