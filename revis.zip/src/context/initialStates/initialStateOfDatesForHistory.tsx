const datesBeingCompared: { [endpoint: string]: string[] } = {};

export default datesBeingCompared;
