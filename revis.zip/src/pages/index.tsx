import React from "react";
import LandingPage from "../components/StaticPages/LandingPageContainer";

export default function landingPage() {
  return <LandingPage />;
}
