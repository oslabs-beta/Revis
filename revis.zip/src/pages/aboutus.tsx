import React from 'react';
import AboutUs from '../components/StaticPages/AboutUs';


function aboutus() {
  return (
    <div>
      <AboutUs />
    </div>
  );
}

export default aboutus;
